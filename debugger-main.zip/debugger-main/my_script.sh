#!/bin/bash

echo hello
echo $GITHUB_CREDENTIALS
